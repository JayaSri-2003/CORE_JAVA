package com.placementmanagementsystem.service;
	import com.placementmanagementsystem.dto.PlacementDTO;
	import java.util.List;

	public interface PlacementService {
	    PlacementDTO addPlacement(PlacementDTO placementDTO);
	    List<PlacementDTO> getAllPlacements();
	    PlacementDTO getPlacementById(Long id);
	    String deletePlacement(Long id);
	}
	

