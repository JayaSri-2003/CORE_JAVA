package com.placementmanagementsystem.service;
import com.placementmanagementsystem.dto.PlacementDTO;
import com.placementmanagementsystem.mapper.PlacementMapper;
import com.placementmanagementsystem.model.Placement;
import com.placementmanagementsystem.repository.PlacementRepository;
import com.placementmanagementsystem.exception.PlacementNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PlacementServiceImpl implements PlacementService {

    private final PlacementRepository placementRepository;

    @Autowired
    public PlacementServiceImpl(PlacementRepository placementRepository) {
        this.placementRepository = placementRepository;
    }

    @Override
    public PlacementDTO addPlacement(PlacementDTO placementDTO) {
        Placement placement = PlacementMapper.toEntity(placementDTO);
        placement = placementRepository.save(placement);
        return PlacementMapper.toDTO(placement);
    }

    @Override
    public List<PlacementDTO> getAllPlacements() {
        return placementRepository.findAll().stream()
                .map(PlacementMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public PlacementDTO getPlacementById(Long id) {
        return placementRepository.findById(id)
                .map(PlacementMapper::toDTO)
                .orElseThrow(() -> new PlacementNotFoundException("Placement not found"));
    }

    @Override
    public String deletePlacement(Long id) {
        if (placementRepository.existsById(id)) {
            placementRepository.deleteById(id);
            return "Placement deleted successfully";
        }
        throw new PlacementNotFoundException("Placement not found");
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
