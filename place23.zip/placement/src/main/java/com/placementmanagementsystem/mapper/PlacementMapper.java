package com.placementmanagementsystem.mapper;
	import com.placementmanagementsystem.dto.PlacementDTO;
	import com.placementmanagementsystem.model.Placement;

	public class PlacementMapper {

	    public static Placement toEntity(PlacementDTO placementDTO) {
	        return new Placement(
	            placementDTO.getStudentName(),
	            placementDTO.getCompanyName(),
	            placementDTO.getJobRole(),
	            placementDTO.getPlacementDate(),
	            placementDTO.getSalaryPackage()
	        );
	    }

	    public static PlacementDTO toDTO(Placement placement) {
	        return new PlacementDTO(
	            placement.getStudentName(),
	            placement.getCompanyName(),
	            placement.getJobRole(),
	            placement.getPlacementDate(),
	            placement.getSalaryPackage()
	        );
	    }
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
