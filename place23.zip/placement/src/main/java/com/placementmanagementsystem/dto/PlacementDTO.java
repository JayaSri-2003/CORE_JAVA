package com.placementmanagementsystem.dto;
	import java.time.LocalDate;

	public class PlacementDTO {

	    private String studentName;
	    private String companyName;
	    private String jobRole;
	    private LocalDate placementDate;
	    private Double salaryPackage;

	    public PlacementDTO() {}

	    public PlacementDTO(String studentName, String companyName, String jobRole, LocalDate placementDate, Double salaryPackage) {
	        this.studentName = studentName;
	        this.companyName = companyName;
	        this.jobRole = jobRole;
	        this.placementDate = placementDate;
	        this.salaryPackage = salaryPackage;
	    }

	    public String getStudentName() { return studentName; }
	    public void setStudentName(String studentName) { this.studentName = studentName; }

	    public String getCompanyName() { return companyName; }
	    public void setCompanyName(String companyName) { this.companyName = companyName; }

	    public String getJobRole() { return jobRole; }
	    public void setJobRole(String jobRole) { this.jobRole = jobRole; }

	    public LocalDate getPlacementDate() { return placementDate; }
	    public void setPlacementDate(LocalDate placementDate) { this.placementDate = placementDate; }

	    public Double getSalaryPackage() { return salaryPackage; }
	    public void setSalaryPackage(Double salaryPackage) { this.salaryPackage = salaryPackage; }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
