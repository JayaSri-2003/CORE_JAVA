package com.placementmanagementsystem.controller;
	import com.placementmanagementsystem.dto.PlacementDTO;
	import com.placementmanagementsystem.service.PlacementService;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.*;

	import java.util.List;

	@RestController
	@RequestMapping("/api/placements")
	public class PlacementController {

	    private final PlacementService placementService;

	    @Autowired
	    public PlacementController(PlacementService placementService) {
	        this.placementService = placementService;
	    }

	    @PostMapping
	    public PlacementDTO addPlacement(@RequestBody PlacementDTO placementDTO) {
	        return placementService.addPlacement(placementDTO);
	    }

	    @GetMapping
	    public List<PlacementDTO> getAllPlacements() {
	        return placementService.getAllPlacements();
	    }

	    @GetMapping("/{id}")
	    public PlacementDTO getPlacementById(@PathVariable Long id) {
	        return placementService.getPlacementById(id);
	    }

	    @DeleteMapping("/{id}")
	    public String deletePlacement(@PathVariable Long id) {
	        return placementService.deletePlacement(id);
	    }
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
