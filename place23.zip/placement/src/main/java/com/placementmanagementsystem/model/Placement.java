package com.placementmanagementsystem.model;
	import jakarta.persistence.*;
	import java.time.LocalDate;

	@Entity
	@Table(name = "placements")
	public class Placement {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private String studentName;
	    private String companyName;
	    private String jobRole;
	    private LocalDate placementDate;
	    private Double salaryPackage;

	    // Constructors, Getters, and Setters
	    public Placement() {}

	    public Placement(String studentName, String companyName, String jobRole, LocalDate placementDate, Double salaryPackage) {
	        this.studentName = studentName;
	        this.companyName = companyName;
	        this.jobRole = jobRole;
	        this.placementDate = placementDate;
	        this.salaryPackage = salaryPackage;
	    }

	    public Long getId() { return id; }
	    public void setId(Long id) { this.id = id; }

	    public String getStudentName() { return studentName; }
	    public void setStudentName(String studentName) { this.studentName = studentName; }

	    public String getCompanyName() { return companyName; }
	    public void setCompanyName(String companyName) { this.companyName = companyName; }

	    public String getJobRole() { return jobRole; }
	    public void setJobRole(String jobRole) { this.jobRole = jobRole; }

	    public LocalDate getPlacementDate() { return placementDate; }
	    public void setPlacementDate(LocalDate placementDate) { this.placementDate = placementDate; }

	    public Double getSalaryPackage() { return salaryPackage; }
	    public void setSalaryPackage(Double salaryPackage) { this.salaryPackage = salaryPackage; }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
